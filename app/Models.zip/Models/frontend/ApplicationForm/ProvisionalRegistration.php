<?php

namespace App\Models\frontend\ApplicationForm;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\HasWorkflow;
use App\Traits\HasDocuments;
use App\Models\User;
class ProvisionalRegistration extends Model
{
    use HasFactory, HasWorkflow, HasDocuments;
    protected $table = 'provisional_registrations';
    protected $fillable = [
        'user_id',
        'application_id',
        'registration_id',
        'application_form_id',
        'slug_id',
        'is_apply',
        'submitted_at',
        // Step 1
        'applicant_name',
        'company_name',
        'enterprise_type',
        'aadhar_number',
        'application_category',
        'region_id',
        'district_id',
        // Step 2
        'site_address',
        'udyog_aadhar',
        'gst_number',
        'zone',
        'project_type',
        'expansion_details',
        'entrepreneurs_profile',
        'project_category',
        'other_category',
        'project_subcategory',
        'project_description',
        // Step 3
        'land_area',
        'land_ownership_type',
        'building_ownership_type',
        'project_cost',
        'total_employees',
        'investment_components',
        // Step 4
        'means_of_finance',
        // Step 5
        'enclosures',
        'other_documents',
        // Step 6
        'declaration_accepted',
        'place',
        'date',
        'signature_path',
        // Progress
        'current_step',
        'progress',
        'is_completed',
        'status'
    ];

    protected $guarded = [];

    protected $casts = [
        'progress' => 'array',
        'site_address' => 'array',
        'entrepreneurs_profile' => 'array',
        'expansion_details' => 'array',
        'investment_components' => 'array',
        'means_of_finance' => 'array',
        'enclosures' => 'array',
        'other_documents' => 'array',
        'declaration_accepted' => 'boolean',
        'is_completed' => 'boolean',
        'is_apply' => 'boolean',
    ];

    public function getDynamicDocuments()
    {
        $docs = [];

        $enclosureLabels = [
            'commencement_certificate' => 'Commencement Certificate',
            'sanctioned_plan' => 'Sanctioned Plan / Layout',
            'proof_of_identity' => 'Proof of Identity',
            'proof_of_address' => 'Proof of Address',
            'land_ownership' => 'Land Ownership Document (7/12)',
            'project_report' => 'Project Report',
            'incorporation_documents' => 'Incorporation Documents (MOA/AOA/Deed)',
            'gst_registration' => 'GST Registration Certificate',
            'special_category_proof' => 'Special Category Proof',
            'ca_certificate' => 'CA Certificate',
            'processing_fee_challan' => 'Processing Fee Challan',
        ];

        // Enclosures
        if (!empty($this->enclosures) && is_array($this->enclosures)) {
            foreach ($this->enclosures as $key => $data) {
                if (!empty($data['file_path'])) {
                    $docs[] = [
                        'key' => "enclosures.{$key}",
                        'label' => $enclosureLabels[$key] ?? ucwords(str_replace('_', ' ', $key)),
                        'file_path' => $data['file_path']
                    ];
                }
            }
        }

        // Other Documents
        if (!empty($this->other_documents) && is_array($this->other_documents)) {
            foreach ($this->other_documents as $index => $data) {
                if (!empty($data['file_path'])) {
                    $docs[] = [
                        'key' => "other_documents.{$index}",
                        'label' => $data['name'] ?? "Other Document " . ($index + 1),
                        'file_path' => $data['file_path']
                    ];
                }
            }
        }

        // Signature
        if (!empty($this->signature_path)) {
            $docs[] = [
                'key' => 'signature_path',
                'label' => 'Signature',
                'file_path' => $this->signature_path
            ];
        }

        return $docs;
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function application()
    {
        return $this->belongsTo(Application::class);
    }

    public function updateProgress($step)
    {
        $progress = $this->progress ?? ['done' => 0, 'total' => 6];

        if ($step > $progress['done']) {
            $progress['done'] = $step;
            $this->progress = $progress;
            $this->current_step = $step + 1 <= 6 ? $step + 1 : 6;
            $this->save();
        }

        return $this;
    }

    public function markAsCompleted()
    {
        $this->is_completed = true;
        $this->current_step = 6;
        $this->progress = ['done' => 6, 'total' => 6];
        $this->status = 'submitted';
        $this->status = 'submitted';
        $this->submitted_at = now();
        $this->save();

        return $this;
    }
}
