<?php

namespace App\Http\Controllers\frontend\Api\ApplicationFormApi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\frontend\ApplicationForm\Application;
use App\Models\frontend\ApplicationForm\ApplicantDetail;
use App\Models\frontend\ApplicationForm\PropertyDetail;
use App\Models\frontend\ApplicationForm\Accommodation;
use App\Models\frontend\ApplicationForm\Facility;
use App\Models\frontend\ApplicationForm\PhotosSignature;
use App\Models\frontend\ApplicationForm\Enclosure;
use App\Models\frontend\ApplicationForm\Document;
use App\Models\Admin\ApplicationForm;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\District;
use App\Models\Country;
use App\Models\State;
use App\Models\Admin\master\Enterprise;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use App\Models\frontend\Api\ApplicationMovement;
class TourismRegistrationController extends Controller
{
      
    public function index()
    {
        
        $application_form = ApplicationForm::where('is_active', 1)->get();
        if(!$application_form){
            return response()->json([
                'status' => false,
                'message' => 'No Available Application Forms.'
            ], 400);
        } else {
            return response()->json([
                'status' => true,
                'message' => 'All Application Forms.',
                'data' => $application_form,
            ]);
        }
    }

    public function apply(Request $request, $slug)
    {
        $validTypes = [
            'registration-of-tourism-villas',
            'registration-of-tourism-apartments',
            'registration-of-homestays',
            'registration-of-vacation-homes'
        ];

        if (!in_array($slug, $validTypes)) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid Application type provided.'
            ], 400);
        }

       
        $validator = Validator::make($request->all(), [

            'name' => 'required|string|max:120',
            'phone' => ['required','regex:/^[6-9][0-9]{9}$/','unique:users,phone'],
            'email' => 'required|email|unique:users,email',
            'aadhaar' => 'nullable|digits:12|unique:users,aadhar',

            'business_name' => 'required|string|max:120',
            'business_type' => 'required|exists:enterprises,id',
            'state' => 'required|string|max:100',
            'district' => 'required|string|max:120',

            'pan' => ['required','regex:/^[A-Z]{5}[0-9]{4}[A-Z]$/'],
            'business_pan' => ['nullable','regex:/^[A-Z]{5}[0-9]{4}[A-Z]$/'],
            'udyam' => 'nullable|string|max:30',

            'ownership_proof_type' => 'required|string',
            'is_property_rented' => 'required|boolean',
            'operator_name' => 'nullable|string|max:120',

            // 'ownership_proof' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
            // 'rental_agreement' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

         $data = $validator->validated();

        DB::beginTransaction();

        try {
         $regId = $this->generateUniqueRegistrationId();

        
         $user = User::create([
            'name' => $data['name'], 
            'username' => $data['name'],
            'registration_id' => $regId,
            'image' => null,
            'phone' => $data['phone'],
            'email' => $data['email'],
            'role' => 'user',
            'status' => 'active',
            'email_verified_at' => now(),
            'phone_verified_at' => now(), 
            'is_email_verified' => true,
            'is_phone_verified' => true,
            'is_aadhar_verified' => false, 
            'password' => Hash::make($data['phone']),
            'aadhar' => $data['aadhaar'] ?? null,
        ]);

        if(!$user){
             return response()->json([
                'status' => false,
                'message' => 'User Data not saved.'
            ], 400);
        }

          $form = ApplicationForm::where('is_active',1)
                ->where('slug',$slug)
                ->first();

            if (!$form) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid Application Form.'
                ], 400);
            }


             $application = Application::create([
                'user_id' => $user->id,
                'slug_id' => (string) Str::ulid(),
                'status' => 'draft',
                'is_apply' => false,
                'application_form_id' => $form->id,
                'current_step' => 1,
                'region_id' => $request->region_id ?? null,
                'district_id' => $request->region_district_id ?? null,
                'is_maitri' => 1,
            ]);

             $this->saveApplicant($application, $user->id, $request);
             $this->saveProperty($application, $request);
             $this->saveAccommodation($application, $request);
             $this->saveFacilities($application, $request);
             $this->savePhotos($application, $request);
             $this->saveEnclosures($application,$request);
          $this->submit($application,$request);
              DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Application created successfully',
                'application_id' => $application->registration_id ?? null,
            ]);

            } catch (\Throwable $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);
        }


    }
  /** Step 1: Applicant */
       public function saveApplicant(Application $application, $UserID, Request $r)
        {
            $applicant = $application->applicant;
            $existingOwnership = optional($applicant)->ownership_proof;
            $existingRental = optional($applicant)->rental_agreement;
            $isPropertyRented = filter_var($r->input('is_property_rented', false), FILTER_VALIDATE_BOOLEAN);

      
            $payload = [
            'user_id' => $UserID,
            'application_id' => $application->id,
            'name' => $r->name,
            'phone' => $r->phone,
            'email' => $r->email,
            'business_name' => $r->business_name,
            'business_type' => $r->business_type,
            'state' => $r->state,
            'district' => $r->district,
            'pan' => $r->pan,
            'business_pan' => $r->business_pan,
            'aadhaar' => $r->aadhaar,
            'udyam' => $r->udyam,
            'ownership_proof_type' => $r->ownership_proof_type,
            'is_property_rented' => (bool)$r->is_property_rented,
            'operator_name' => $r->operator_name,
            ];

            foreach (['ownership_proof', 'rental_agreement'] as $fileKey) {
                if ($r->hasFile($fileKey)) {
                    $file = $r->file($fileKey);
                    $ext = $file->getClientOriginalExtension();

                    $filename = "{$fileKey}_{$application->id}." . $ext;
                    $folder = "applications/{$application->id}/applicant";
                    $old = optional($applicant)->{$fileKey} ?? null;
                    if ($old && Storage::disk('public')->exists($old)) {
                        Storage::disk('public')->delete($old);
                    }
                    $path = $file->storeAs($folder, $filename, 'public');
                    $payload[$fileKey] = $path;
                }
            }

            $application->applicant()->updateOrCreate(
                ['application_id' => $application->id],
                $payload
            );
            return true;
            
            
        }
    

     /** Step 2: Property */  
    public function saveProperty(Application $application, Request $r)
    { 
        $property = $application->property;
        $existingAddress = optional($property)->address_proof;
        $isOperational = filter_var($r->input('is_operational', false), FILTER_VALIDATE_BOOLEAN);
        
        $validator = Validator::make($r->all(), [
        'property_name' => 'required|string|max:160',
        'geo_link' => 'nullable|string|max:255',
        'address' => 'required|string|max:1000',
        'address_proof_type' => 'required|in:Latest Electricity Bill,Water Bill,Other',
        'address_proof' => 'nullable|file|mimes:pdf,jpg,jpeg,png,webp|max:2048',
        'total_area_sqft' => 'nullable|integer|min:0',
        'mahabooking_reg_no' => 'nullable|string|max:80',
        'is_operational' => 'required|boolean',
         'operational_since' => $isOperational ? 'nullable|integer|min:1900|max:2050' : 'nullable|integer',
        'guests_till_march' => $isOperational ? 'nullable|integer|min:0' : 'nullable|integer',
        'district_id' => 'required|exists:districts,id',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => false,
            'errors' => $validator->errors()
        ], 422);
    }

        $data = $validator->validated();

        DB::beginTransaction();
        try {
            
            $payload = [
            'user_id' => $application->user_id,
            'application_id' => $application->id,
            'property_name' => $data['property_name'],
            'geo_link' => $data['geo_link'] ?? null,
            'address' => $data['address'],
            'address_proof_type' => $data['address_proof_type'],
            'total_area_sqft' => $data['total_area_sqft'] ?? null,
            'mahabooking_reg_no' => $data['mahabooking_reg_no'] ?? null,
            'is_operational' => (bool)$data['is_operational'],
            'operational_since' => $data['operational_since'] ?? null,
            'guests_till_march' => $data['guests_till_march'] ?? null,
            'district_id' => $data['district_id'],
        ];
            if ($r->hasFile('address_proof')) {
                $file = $r->file('address_proof');
                $ext = $file->getClientOriginalExtension();

                $dir = "applications/{$application->id}/property";
                $filename = 'address_proof_' . now()->format('Ymd_His') . '_' . uniqid() . '.' . $ext;
                if ($existingAddress && Storage::disk('public')->exists($existingAddress)) {
                    Storage::disk('public')->delete($existingAddress);
                }
                $path = $file->storeAs($dir, $filename, 'public');
                $payload['address_proof'] = $path;
            } 

            $application->property()->updateOrCreate(
                ['application_id' => $application->id],
                $payload
            );
            DB::commit();
               return true;
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('saveProperty error: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
             return response()->json([
            'status' => false,
            'message' => $e->getMessage()
        ], 500);
        }
    }

    public function saveAccommodation(Application $application, Request $r)
    {
        $validator = Validator::make($r->all(), [
        'flats_count' => 'required|integer|min:1',
       'flat_types' => ['sometimes', 'array'],
        'flat_types.*' => ['nullable', 'string', 'max:200'],
        'has_dustbins' => 'required|boolean',
        'attached_toilet' => 'required|boolean',
        'road_access' => 'required|boolean',
        'food_on_request' => 'required|boolean',
        'payment_upi' => 'required|boolean',
    ]);

    if ($validator->fails()) {
        return response()->json(['status'=>false,'errors'=>$validator->errors()],422);
    }

     $data = $validator->validated();

        $types = $r->input('flat_types', []);
        if (!is_array($types))
            $types = [$types];

        // trim, remove blanks, unique
        $types = array_values(array_unique(array_filter(array_map(function ($v) {
            return is_string($v) ? trim($v) : '';
        }, $types))));

        if (count($types) === 0) {
            return response()->json([
            'status' => false,
            'flat_types' => 'Please add at least one flat/room type.'
        ], 500);
        }

        $payload = [
            'user_id' => $application->user_id,
            'application_id' => $application->id,
            'flats_count' => (int) $data['flats_count'] ?? null,
            'flat_types' => $types,
            'has_dustbins' => (bool) $data['has_dustbins'],
            'attached_toilet' => (bool) $data['attached_toilet'],
            'road_access' => (bool) $data['road_access'],
            'food_on_request' => (bool) $data['food_on_request'],
            'payment_upi' => (bool) $data['payment_upi'],
        ];

        DB::beginTransaction();
        try {
            $application->accommodation()->updateOrCreate(
                ['application_id' => $application->id],
                $payload
            );
            DB::commit();
            return true;
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('saveAccommodation error: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
           return response()->json(['status'=>false,'message'=>$e->getMessage()],500);
           
        }
    }

    /** Step 4: Facilities */
    public function saveFacilities(Application $application, Request $r)
    {
        $validator = Validator::make($r->all(), [
        'facilities' => ['required', 'array', 'min:1'],
            'facilities.*' => ['integer', 'exists:tourismfacilities,id'],
            'gras_paid' => ['required', 'in:0,1'],
    ]);

    if ($validator->fails()) {
        return response()->json(['status'=>false,'errors'=>$validator->errors()],422);
    }

    $data = $validator->validated();

        $facilityIds = collect($data['facilities'])
            ->map(fn($id) => (int) $id)
            ->filter()->unique()->values()->all();

        if (empty($facilityIds)) {
            return back()->withErrors(['facilities' => 'Please select at least one facility.'])
                ->withInput();
        }

        $application->facilities()
            ->updateOrCreate(
                ['application_id' => $application->id],   // lookup
                [
                    'facilities' => $facilityIds,     // JSON
                    'gras_paid' => (int) $data['gras_paid'],
                    'user_id' => $application->user_id,
                ]
            );

       return true;
    }

    /** Step 5: Photo & Signature (signature file only; photos uploaded via UploadController) */
    public function savePhotos(Application $application, Request $r)
    {
        // Laravel validation: size in KB (50 => 50KB, 200 => 200KB)
        $validator = Validator::make($r->all(), [
        'applicant_signature' => ['nullable', 'file', 'mimes:jpg,jpeg,png', 'max:50'],
            'applicant_image' => ['nullable', 'file', 'mimes:jpg,jpeg,png', 'max:200'],
        ], [
            'applicant_signature.max' => 'Signature must be less than 50KB',
            'applicant_image.max' => 'Photo must be less than 200KB',
            'applicant_signature.mimes' => 'Signature must be JPG/JPEG/PNG format',
            'applicant_image.mimes' => 'Photo must be JPG/JPEG/PNG format',
        ]);
   
    if ($validator->fails()) {
        return response()->json(['status'=>false,'errors'=>$validator->errors()],422);
    }

        DB::beginTransaction();

        try {
            $existing = optional($application->photos);

            $payload = [
                'user_id' => $application->user_id,
                'application_id' => $application->id,
            ];

            /**-----------------------------------------
             *  APPLICANT SIGNATURE
             ------------------------------------------*/
            if ($r->hasFile('applicant_signature')) {

                $file = $r->file('applicant_signature');
                $ext = $file->getClientOriginalExtension();

                $dir = "applications/{$application->id}/photos";
                $filename = "signature_{$application->id}." . $ext;

                $path = $file->storeAs($dir, $filename, 'public');

                if (
                    $existing && $existing->applicant_signature &&
                    Storage::disk('public')->exists($existing->applicant_signature) &&
                    $existing->applicant_signature !== $path
                ) {
                    Storage::disk('public')->delete($existing->applicant_signature);
                }

                $payload['applicant_signature'] = $path;

            } elseif ($r->filled('existing_applicant_signature')) {

                $payload['applicant_signature'] = $r->existing_applicant_signature;
            }



            /**-----------------------------------------
             *  APPLICANT PHOTO
             ------------------------------------------*/
            if ($r->hasFile('applicant_image')) {

                $file = $r->file('applicant_image');
                $ext = $file->getClientOriginalExtension();

                $dir = "applications/{$application->id}/photos";
                $filename = "photo_{$application->id}." . $ext;

                $path = $file->storeAs($dir, $filename, 'public');

                if (
                    $existing && $existing->applicant_image &&
                    Storage::disk('public')->exists($existing->applicant_image) &&
                    $existing->applicant_image !== $path
                ) {
                    Storage::disk('public')->delete($existing->applicant_image);
                }

                $payload['applicant_image'] = $path;

            } elseif ($r->filled('existing_applicant_image')) {

                $payload['applicant_image'] = $r->existing_applicant_image;
            }


            /**-----------------------------------------
             *  CREATE/UPDATE
             ------------------------------------------*/
            $application->photos()
                ->updateOrCreate(
                    ['application_id' => $application->id],
                    $payload
                );


            DB::commit();
            return true;
        } catch (\Throwable $e) {

            DB::rollBack();

            Log::error("PHOTO SAVE ERROR: " . $e->getMessage(), [
                'app_id' => $application->id,
            ]);

           return response()->json(['status'=>false,'message'=>$e->getMessage()],500);
        }
    }

    

    public function saveEnclosures(Application $application, Request $r)
{
    $validator = Validator::make($r->all(), [
        'file' => 'required|array',
        'file.*' => 'required',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => false,
            'errors' => $validator->errors()
        ], 422);
    }

    DB::beginTransaction();

    try {

        foreach ($r->file('file') as $category => $files) {

            // Single file ko array bana do
            if (!is_array($files)) {
                $files = [$files];
            }

            // 🔥 PROPERTY PHOTOS LIMIT
            if ($category === 'property_photos') {
                if (count($files) > 5) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Maximum 5 property photos allowed'
                    ], 422);
                }
            }

            foreach ($files as $uploaded) {

                if (!$uploaded) continue;

                // VALIDATE EACH FILE
                $fileValidator = Validator::make(
                    ['file' => $uploaded],
                    ['file' => 'required|file|mimes:pdf,jpg,jpeg,png,webp|max:20480']
                );

                if ($fileValidator->fails()) {
                    return response()->json([
                        'status' => false,
                        'errors' => $fileValidator->errors()
                    ], 422);
                }

                $mime = $uploaded->getMimeType();
                $isImage = str_starts_with($mime, 'image/');

                $dir = "applications/{$application->id}/docs";

                if ($isImage) {

                    $image = Image::read($uploaded->getRealPath())
                        ->scaleDown(2000, 2000);

                    $encoded = null;

                    foreach ([80,70,60,50,40,30] as $q) {
                        $data = (string) $image->encodeByExtension('webp', quality: $q);
                        if (strlen($data) <= 200 * 1024) {
                            $encoded = $data;
                            break;
                        }
                    }

                    if (!$encoded) {
                        return response()->json([
                            'status' => false,
                            'message' => 'Image too large (must be <200KB)'
                        ], 422);
                    }

                    $name = Str::slug(pathinfo($uploaded->getClientOriginalName(), PATHINFO_FILENAME))
                        . '_' . time() . '.webp';

                    $path = $dir . '/' . $name;

                    Storage::disk('public')->put($path, $encoded);

                } else {

                    $name = Str::slug(pathinfo($uploaded->getClientOriginalName(), PATHINFO_FILENAME))
                        . '_' . time() . '.' . $uploaded->getClientOriginalExtension();

                    $path = $uploaded->storeAs($dir, $name, 'public');
                }

                // ✅ STORE IN DB
                $application->documents()->create([
                    'user_id' => $application->user_id,
                    'category' => $category,
                    'path' => $path,
                    'original_name' => $uploaded->getClientOriginalName(),
                    'size' => Storage::disk('public')->size($path),
                ]);
            }
        }

        // ✅ ENCLOSURE META SAVE
        $application->enclosures()->updateOrCreate(
            ['application_id' => $application->id],
            [
                'user_id' => $application->user_id,
                'meta' => $application->documents()->pluck('category')->unique()->values()
            ]
        );

        DB::commit();

        return true;

    } catch (\Throwable $e) {

        DB::rollBack();

        return response()->json([
            'status' => false,
            'message' => $e->getMessage()
        ], 500);
    }
}



    public function submit(Application $application, Request $r)
    {
        foreach (['applicant','property','accommodation','facilities','photos','enclosures'] as $rel) {
        if(!$application->$rel){
            return response()->json([
                'status'=>false,
                'message'=>"$rel step incomplete"
            ],422);
        }
    }
        

        $requiredCats = ['aadhar', 'pan', 'business_reg', 'ownership', 'property_photos', 'character', 'society_noc', 'building_perm', 'gras_copy', 'undertaking'];
        $have = $application->documents()->pluck('category')->unique()->toArray();

        // ensure property_photos >= 5
        $propertyPhotosCount = $application->documents()->where('category', 'property_photos')->count();
        if (!in_array('property_photos', $have) || $propertyPhotosCount < 5) {
             return response()->json([
                'status'=>false,
                'message'=>'Property photos are incomplete (minimum 5 required).'
            ],422);
            
        }

        foreach ($requiredCats as $rc) {
            if (!in_array($rc, $have)) {
                return response()->json([
                    'status' => false,
                    'message' => "Missing required document: $rc"
                ], 422);
            }
        }

         $application->update([
        'status'=>'submitted',
        'is_apply'=>true,
        'current_step'=>7,
        'registration_id'=>'TV'.now()->format('Ymd').strtoupper(Str::random(6)),
        'submitted_at'=>now(),
    ]);

        ApplicationMovement::create([
        'application_id'   => $application->registration_id ?? '',
        'desk_number'      => 1,
        'officer_name'     => 'Clerk',
        'action'           => 'Submitted',
        'action_datetime'  => now(),
        'remarks'          => 'submitted'
    ]);
    return true;
    }

    protected function generateUniqueRegistrationId($prefix = 'MV')
        {
            do {
                $id = strtoupper($prefix . '-' . Str::upper(Str::random(8)));
            } while (User::where('registration_id', $id)->exists());
            return $id;
        }


public function TourismVillasForm()
        {
            $application_form = ApplicationForm::where('is_active', 1)
            ->where('slug','registration-of-tourism-villas')
            ->first();
            if(!$application_form){
                return response()->json([
                    'status' => false,
                    'message' => 'No Available Application Forms.'
                ], 400);
            } else {
                return response()->json([
                    'status' => true,
                    'message' => 'Tourism Villas Form.',
                    'data' => $application_form,
                ]);
            }
        }
      public function TourismApartmentsForm()
     {
    $application_form = ApplicationForm::where('is_active', 1)
    ->where('slug','registration-of-tourism-apartments')
    ->first();
        if(!$application_form){
            return response()->json([
                'status' => false,
                'message' => 'No Available Application Forms.'
            ], 400);
        } else {
            return response()->json([
                'status' => true,
                'message' => 'Tourism Apartments Registration Forms.',
                'data' => $application_form,
            ]);
        }
    }
      public function HomestaysForm()
     {
    $application_form = ApplicationForm::where('is_active', 1)
   ->where('slug','registration-of-homestays')
    ->first();
        if(!$application_form){
            return response()->json([
                'status' => false,
                'message' => 'No Available Application Forms.'
            ], 400);
        } else {
            return response()->json([
                'status' => true,
                'message' => 'Homestays Registration Forms.',
                'data' => $application_form,
            ]);
        }
    }
      public function VacationHomesForm()
     {
    $application_form = ApplicationForm::where('is_active', 1)
    ->where('slug','registration-of-vacation-homes')
    ->first();
        if(!$application_form){
            return response()->json([
                'status' => false,
                'message' => 'No Available Application Forms.'
            ], 400);
        } else {
            return response()->json([
                'status' => true,
                'message' => 'Vacation Homes Registration Forms.',
                'data' => $application_form,
            ]);
        }
    
}

}
